# Arun — Cinematic Single-Page Portfolio

A responsive, single-page portfolio with a fixed smoky crimson background, red glow accents, image placeholders, mobile navigation, subtle particles and optional GSAP scroll animations.

## Run it

1. Extract/open the `arun-portfolio` folder in VS Code.
2. Install the **Live Server** extension if needed.
3. Right-click `index.html` → **Open with Live Server**.
4. Internet is needed for Google Fonts and GSAP CDN animations. The page layout and CSS still work without them.

## Add your images

The background image you provided is already included at `assets/background.png` and is used once across the whole page.

Replace these placeholder files by adding your own images with the exact filenames:

- `assets/hero-portrait.png` — transparent PNG portrait is ideal for the hero.
- `assets/about-portrait.jpg` — a second portrait or photo of you working.
- `assets/project-1.png` — screenshot of your first project.
- `assets/project-2.png` — screenshot of your second project.
- `assets/project-3.png` — screenshot of your third project.

You can add `assets/contact-visual.png` later if you want a separate contact image; the current design does not require it. Missing image files show a clearly labelled placeholder rather than a broken-image icon.

## Personalize it before publishing

- In `index.html`, replace the example social URLs with your actual GitHub, LinkedIn, Instagram and X profiles.
- Update the About text with your real education, location and experience. Do not claim skills you have not learned yet.
- Update project titles, descriptions, screenshots, and repository/demo links to match your actual work.
- Change `hello@example.com` to your real public contact email.
- The project cards currently use illustrative starter content. Replace it before publishing.

## Files

- `index.html` — all sections in one scrolling page.
- `style.css` — shared fixed background, visual design, responsive layouts and reduced-motion support.
- `script.js` — mobile navigation, active-section highlighting, particles and GSAP animations.
- `assets/background.png` — the supplied smoky red background.

## Notes

- The same background image stays behind every section; section panels are translucent and do not switch to different page backgrounds.
- This is a frontend-only portfolio. No backend or real form submission is included.
- Replace all placeholder profile and project links with verified URLs before publishing.
