(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  document.documentElement.classList.add('js-motion');
  $('#year').textContent = new Date().getFullYear();

  // Show a named placeholder until a real image file is supplied.
  $$('.image-slot').forEach(slot => {
    const img = $('img', slot);
    if (!img) return;
    const show = () => slot.classList.toggle('has-image', img.complete && img.naturalWidth > 0);
    img.addEventListener('load', show);
    img.addEventListener('error', show);
    if (img.complete) show();
  });

  // Mobile navigation.
  const menuToggle = $('.menu-toggle');
  const nav = $('#site-nav');
  const closeMenu = () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation');
    document.body.classList.remove('menu-open');
  };
  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    nav.classList.toggle('open', open);
    document.body.classList.toggle('menu-open', open);
  });
  $$('.nav-link').forEach(link => link.addEventListener('click', closeMenu));
  window.addEventListener('resize', () => { if (window.innerWidth > 680) closeMenu(); });

  // Header treatment and active navigation state.
  const header = $('.site-header');
  const navLinks = $$('.nav-link');
  const sections = $$('main section[id]');
  const updateHeader = () => header.classList.toggle('scrolled', window.scrollY > 24);
  updateHeader();
  window.addEventListener('scroll', updateHeader, { passive: true });
  if ('IntersectionObserver' in window) {
    const sectionObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        navLinks.forEach(link => {
          const active = link.getAttribute('href') === `#${entry.target.id}`;
          link.classList.toggle('active', active);
          if (active) link.setAttribute('aria-current', 'page');
          else link.removeAttribute('aria-current');
        });
      });
    }, { rootMargin: '-38% 0px -52% 0px', threshold: 0 });
    sections.forEach(section => sectionObserver.observe(section));
  }

  // Small atmospheric particles. Disabled for reduced-motion preferences.
  const canvas = $('#particles');
  if (canvas && !reducedMotion) {
    const ctx = canvas.getContext('2d');
    let width = 0, height = 0, particles = [], frame = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = window.innerWidth; height = window.innerHeight;
      canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`; canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = width < 680 ? 18 : 38;
      particles = Array.from({ length: count }, () => ({ x: Math.random() * width, y: Math.random() * height, r: Math.random() * 1.4 + .3, v: Math.random() * .22 + .06, a: Math.random() * .38 + .08 }));
    };
    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      particles.forEach(p => {
        p.y -= p.v;
        if (p.y < -4) { p.y = height + 4; p.x = Math.random() * width; }
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 55, 72, ${p.a})`; ctx.fill();
      });
      frame = requestAnimationFrame(draw);
    };
    resize(); draw();
    window.addEventListener('resize', resize, { passive: true });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) cancelAnimationFrame(frame);
      else if (!reducedMotion) draw();
    });
  }

  // GSAP progressive enhancement; the site remains usable without the CDN.
  const initAnimations = () => {
    if (reducedMotion || !window.gsap) {
      document.documentElement.classList.remove('js-motion');
      return;
    }
    const gsap = window.gsap;
    const hasScrollTrigger = Boolean(window.ScrollTrigger);
    if (hasScrollTrigger) gsap.registerPlugin(window.ScrollTrigger);
    gsap.timeline({ defaults: { ease: 'power3.out' } })
      .from('.site-header', { y: -24, opacity: 0, duration: .65 })
      .from('.hero-art', { opacity: 0, scale: .92, duration: 1.05 }, '-=.25')
      .from('.hero-copy .eyebrow, .hero-copy h1, .hero-copy h2, .hero-description, .social-row, .hero-actions', { y: 24, opacity: 0, duration: .7, stagger: .09 }, '-=.6');
    gsap.to('.orbit-one', { rotation: 360, duration: 44, repeat: -1, ease: 'none', transformOrigin: '50% 50%' });
    gsap.to('.orbit-two', { rotation: -360, duration: 58, repeat: -1, ease: 'none', transformOrigin: '50% 50%' });
    gsap.to('.planet-glow', { scale: 1.035, duration: 3.6, yoyo: true, repeat: -1, ease: 'sine.inOut' });
    if (hasScrollTrigger) {
      $$('.reveal').forEach(el => gsap.fromTo(el, { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: .75, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 88%', once: true } }));
      gsap.to('.hero-copy', { y: -30, opacity: .65, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
    } else {
      gsap.to('.reveal', { opacity: 1, y: 0, duration: .65, stagger: .04 });
    }
  };
  if (document.readyState === 'complete') initAnimations();
  else window.addEventListener('load', initAnimations, { once: true });
})();
